package winapi

import (
	"fmt"
)

func init() {
	fmt.Println("winapi.init")
}
